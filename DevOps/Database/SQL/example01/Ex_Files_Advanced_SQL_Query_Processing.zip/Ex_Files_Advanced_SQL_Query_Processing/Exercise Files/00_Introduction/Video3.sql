-------------------------------------
-- LinkedIn Learning ----------------
-- Advanced SQL - Query Processing --
-- Ami Levin 2020 -------------------
-- .\Chapter1\Video3.sql ------------
-------------------------------------

-- SQL Server download
-- https://www.microsoft.com/en-us/sql-server/sql-server-downloads

-- SQL Server installation guide
-- https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server?view=sql-server-ver15

-- SQL Server Management Studio
-- https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver15

-- PostgreSQL download
-- https://www.postgresql.org/download/

-- PostgreSQL installation guide
-- https://www.postgresql.org/docs/current/tutorial-install.html

-- DBeaver
-- https://dbeaver.io/

-- DB fiddle
-- https://dbfiddle.uk/
