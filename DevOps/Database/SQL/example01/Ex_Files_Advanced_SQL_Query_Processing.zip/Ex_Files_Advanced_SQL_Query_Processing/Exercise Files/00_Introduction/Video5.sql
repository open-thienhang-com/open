-------------------------------------
-- LinkedIn Learning ----------------
-- Advanced SQL - Query Processing --
-- Ami Levin 2020 -------------------
-- .\Chapter1\Video5.sql ------------
-------------------------------------

-- Course code files - demos, challenges, and solutions
-- https://github.com/ami-levin/LinkedIn/tree/master/Query%20Processing
