------------------------------------
-- LinkedIn Learning ---------------
-- Advanced SQL - Query Processing -
-- Ami Levin 2020 ------------------
-- .\Chapter6\Video1.sql -----------
------------------------------------

-- Edgar F. Codd
-- https://en.wikipedia.org/wiki/Edgar_F._Codd
-- https://amzn.to/2OIMOQg

-- Chris Date
-- https://en.wikipedia.org/wiki/Christopher_J._Date
-- https://amzn.to/31KbZXS

-- Joe Celko
-- https://en.wikipedia.org/wiki/Joe_Celko
-- https://amzn.to/2SDQzYh

-- David McGoveran
-- https://en.wikipedia.org/wiki/David_McGoveran

-- Fabian Pascal
-- https://en.wikipedia.org/wiki/Fabian_Pascal
-- http://www.dbdebunk.com/

-- Hugh Darwen
-- https://en.wikipedia.org/wiki/Hugh_Darwen
